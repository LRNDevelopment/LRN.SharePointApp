using LRN.SharePointClient.Abstractions;
using Microsoft.Extensions.Logging;
using Microsoft.Graph;
using Microsoft.Graph.Drives.Item.Items.Item.CreateUploadSession;
using Microsoft.Graph.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace LRN.SharePointClient.Graph
{
	public class GraphSharePointClient : ISharePointClient
	{
		private readonly GraphServiceClient _graphClient;
		private readonly HttpClient _httpClient;
		private readonly ILogger<GraphSharePointClient> _logger;
		// Threshold for switching to upload session (4 MB)
		private const int LargeFileThreshold = 4 * 1024 * 1024;
		private const int ChunkSize = 5 * 1024 * 1024; // 5 MB

		public GraphSharePointClient(
		GraphServiceClient graphClient,
		HttpClient httpClient,
		ILogger<GraphSharePointClient> logger)
		{
			_graphClient = graphClient ?? throw new ArgumentNullException(nameof(graphClient));
			_httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
			_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		}
		/// <summary>
		/// Public entry point used by FolderSyncEngine.
		/// </summary>
		public async Task UploadFileAsync(
			string driveId,
			string folderPath,
			string localFilePath,
			string targetFileName,
			bool overwrite,
			CancellationToken ct)
		{
			if (string.IsNullOrWhiteSpace(driveId))
				throw new ArgumentNullException(nameof(driveId));
			if (string.IsNullOrWhiteSpace(localFilePath))
				throw new ArgumentNullException(nameof(localFilePath));
			if (string.IsNullOrWhiteSpace(targetFileName))
				throw new ArgumentNullException(nameof(targetFileName));

			var fileInfo = new FileInfo(localFilePath);
			if (!fileInfo.Exists)
				throw new FileNotFoundException("Local file not found.", localFilePath);

			var remotePath = string.IsNullOrWhiteSpace(folderPath)
				? targetFileName
				: $"{folderPath.TrimEnd('/', '\\')}/{targetFileName}";

			_logger.LogInformation(
				"Uploading file '{LocalFile}' to '{RemotePath}' in drive '{DriveId}'",
				localFilePath, remotePath, driveId);

			try
			{
				await UploadInternalAsync(driveId, remotePath, localFilePath, overwrite, ct);
			}
			catch (Exception ex) when (overwrite && IsTooManyMinorVersionsError(ex))
			{
				_logger.LogWarning(ex,
					"Upload blocked by SharePoint minor-version limit for '{RemotePath}'. " +
					"Deleting existing remote file and retrying as a fresh upload.",
					remotePath);

				await DeleteRemoteFileIfExistsAsync(driveId, remotePath, ct);
				await WaitUntilRemoteFileDeletedAsync(driveId, remotePath, ct);
				await Task.Delay(1000, ct);

				await UploadInternalAsync(driveId, remotePath, localFilePath, overwrite: false, ct);
			}
		}

		private async Task UploadInternalAsync(
			string driveId,
			string remotePath,
			string localFilePath,
			bool overwrite,
			CancellationToken ct)
		{
			var fileInfo = new FileInfo(localFilePath);

			if (fileInfo.Length <= LargeFileThreshold)
			{
				await UploadSmallFileAsync(driveId, remotePath, localFilePath, overwrite, ct);
			}
			else
			{
				await UploadLargeFileWithSessionAsync(driveId, remotePath, localFilePath, overwrite, ct);
			}
		}

		private static bool IsTooManyMinorVersionsError(Exception ex)
		{
			var text = ex.ToString();

			return text.Contains("Document has too many minor versions", StringComparison.OrdinalIgnoreCase)
				|| (text.Contains("\"code\":\"notAllowed\"", StringComparison.OrdinalIgnoreCase)
					&& text.Contains("minor versions", StringComparison.OrdinalIgnoreCase));
		}

		private async Task DeleteRemoteFileIfExistsAsync(
			string driveId,
			string remotePath,
			CancellationToken ct)
		{
			try
			{
				var existingItem = await _graphClient
					.Drives[driveId]
					.Root
					.ItemWithPath(remotePath)
					.GetAsync(cancellationToken: ct);

				if (existingItem?.Id == null)
					return;

				await _graphClient
					.Drives[driveId]
					.Items[existingItem.Id]
					.DeleteAsync(cancellationToken: ct);

				_logger.LogInformation("Deleted existing remote file '{RemotePath}' before retry upload.", remotePath);
			}
			catch
			{
				_logger.LogInformation("Remote file '{RemotePath}' was not found during delete retry flow.", remotePath);
			}
		}

		private async Task WaitUntilRemoteFileDeletedAsync(
			string driveId,
			string remotePath,
			CancellationToken ct)
		{
			for (int i = 0; i < 10; i++)
			{
				try
				{
					var item = await _graphClient
						.Drives[driveId]
						.Root
						.ItemWithPath(remotePath)
						.GetAsync(cancellationToken: ct);

					if (item == null)
						return;
				}
				catch
				{
					return;
				}

				await Task.Delay(500, ct);
			}
		}

		private async Task UploadSmallFileAsync(
			string driveId,
			string remotePath,
			string localFilePath,
			bool overwrite,
			CancellationToken ct)
		{
			await EnsureFolderHierarchyExistsAsync(
				driveId,
				Path.GetDirectoryName(remotePath)?.Replace("\\", "/"),
				ct);

			await using var fs = new FileStream(localFilePath, FileMode.Open, FileAccess.Read, FileShare.Read);

			var request = _graphClient
				.Drives[driveId]
				.Root
				.ItemWithPath(remotePath)
				.Content
				.ToPutRequestInformation(fs);

			await _graphClient.RequestAdapter.SendPrimitiveAsync<Stream>(request, cancellationToken: ct);
		}

		/// <summary>
		/// Large file upload using Graph upload session + chunking + retries.
		/// </summary>
		private async Task UploadLargeFileWithSessionAsync(
			string driveId,
			string remotePath,
			string localFilePath,
			bool overwrite,
			CancellationToken ct)
		{
			var fileInfo = new FileInfo(localFilePath);
			var totalSize = fileInfo.Length;

			await EnsureFolderHierarchyExistsAsync(
				driveId,
				Path.GetDirectoryName(remotePath)?.Replace("\\", "/"),
				ct);

			var uploadSession = await CreateUploadSessionInternalAsync(driveId, remotePath, overwrite, ct);
			var uploadUrl = uploadSession.UploadUrl;

			await using var fs = new FileStream(localFilePath, FileMode.Open, FileAccess.Read, FileShare.Read);

			long offset = 0;
			int retryCount = 0;

			while (offset < totalSize)
			{
				ct.ThrowIfCancellationRequested();

				if (uploadSession.ExpirationDateTime < DateTimeOffset.UtcNow.AddMinutes(2))
				{
					_logger.LogWarning(
						"Upload session for '{RemotePath}' is near expiration. Recreating session and restarting upload.",
						remotePath);

					uploadSession = await CreateUploadSessionInternalAsync(driveId, remotePath, overwrite, ct);
					uploadUrl = uploadSession.UploadUrl;
					offset = 0;
					fs.Seek(0, SeekOrigin.Begin);
				}

				var remaining = totalSize - offset;
				var bytesToRead = (int)Math.Min(ChunkSize, remaining);
				var buffer = new byte[bytesToRead];

				var read = await fs.ReadAsync(buffer.AsMemory(0, bytesToRead), ct);
				if (read == 0)
					break;

				var start = offset;
				var end = offset + read - 1;

				using var request = new HttpRequestMessage(HttpMethod.Put, uploadUrl)
				{
					Content = new ByteArrayContent(buffer, 0, read)
				};

				request.Content.Headers.TryAddWithoutValidation("Content-Range", $"bytes {start}-{end}/{totalSize}");

				try
				{
					using var response = await _httpClient.SendAsync(
						request,
						HttpCompletionOption.ResponseContentRead,
						ct);

					if (response.StatusCode == HttpStatusCode.Created ||
						response.StatusCode == HttpStatusCode.OK)
					{
						_logger.LogInformation("Completed upload of '{RemotePath}'", remotePath);
						return;
					}

					if (response.StatusCode == HttpStatusCode.Accepted)
					{
						offset = end + 1;
						retryCount = 0;
						continue;
					}

					var body = await response.Content.ReadAsStringAsync(ct);
					throw new InvalidOperationException($"Upload failed: {response.StatusCode} - {body}");
				}
				catch (Exception ex)
				{
					retryCount++;

					if (retryCount > 3)
					{
						_logger.LogError(ex, "Failed uploading '{RemotePath}' after retries.", remotePath);
						throw new InvalidOperationException($"Failed uploading '{remotePath}' after retries.", ex);
					}

					_logger.LogWarning(
						ex,
						"Error uploading chunk for '{RemotePath}'. Retrying (attempt {Retry})",
						remotePath,
						retryCount);

					await Task.Delay(1500, ct);
					fs.Seek(offset, SeekOrigin.Begin);
				}
			}

			throw new InvalidOperationException($"Failed uploading '{remotePath}'. Upload loop exited unexpectedly.");
		}

		/// <summary>
		/// Ensures the folder hierarchy exists in the drive (creates missing folders).
		/// </summary>
		private async Task EnsureFolderHierarchyExistsAsync(
					string driveId,
					string? folderPath,
					CancellationToken ct)
		{
			if (string.IsNullOrWhiteSpace(folderPath))
				return;

			var segments = folderPath
				.Replace("\\", "/")
				.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

			var currentPath = string.Empty;

			foreach (var segment in segments)
			{
				currentPath = string.IsNullOrEmpty(currentPath)
					? segment
					: $"{currentPath}/{segment}";

				try
				{
					_ = await _graphClient
						.Drives[driveId]
						.Root
						.ItemWithPath(currentPath)
						.GetAsync(cancellationToken: ct);
				}
				catch
				{
					var parentPath = Path.GetDirectoryName(currentPath)?.Replace("\\", "/") ?? string.Empty;

					var folder = new DriveItem
					{
						Name = segment,
						Folder = new Folder(),
						AdditionalData = new Dictionary<string, object>
				{
					{ "@microsoft.graph.conflictBehavior", "replace" }
				}
					};

					if (string.IsNullOrWhiteSpace(parentPath))
					{
						await _graphClient
							.Drives[driveId]
							.Items["root"]
							.Children
							.PostAsync(folder, cancellationToken: ct);
					}
					else
					{
						await _graphClient
							.Drives[driveId]
							.Root
							.ItemWithPath(parentPath)
							.Children
							.PostAsync(folder, cancellationToken: ct);
					}
				}
			}
		}

		/// <summary>
		/// Creates an upload session for the given file path.
		/// </summary>
		private async Task<UploadSession> CreateUploadSessionInternalAsync(
			string driveId,
			string remotePath,
			bool overwrite,
			CancellationToken ct)
		{
			var body = new CreateUploadSessionPostRequestBody
			{
				Item = new DriveItemUploadableProperties
				{
					AdditionalData = new Dictionary<string, object>
					{
						{ "@microsoft.graph.conflictBehavior", overwrite ? "replace" : "fail" }
					}
				}
			};

			var session = await _graphClient
				.Drives[driveId]
				.Root
				.ItemWithPath(remotePath)
				.CreateUploadSession
				.PostAsync(body, cancellationToken: ct);

			if (session == null || string.IsNullOrWhiteSpace(session.UploadUrl))
				throw new InvalidOperationException($"Failed to create upload session for '{remotePath}'.");

			return session;
		}
	}
}